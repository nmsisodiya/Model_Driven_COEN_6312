package com.coen6312.flyair.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Ticket {
	private String id;
	private List<String> travellers;
	private BigDecimal fare;
	private Flight flight;
	private String email;
	private String contactNo;
	private String userID;
	private String name;
	
	public Ticket(){
		flight = new Flight();
		travellers = new ArrayList<String>();
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<String> getTravellers() {
		return travellers;
	}
	public void setTravellers(List<String> travellers) {
		this.travellers = travellers;
	}
	public BigDecimal getFare() {
		return fare;
	}
	public void setFare(BigDecimal fare) {
		this.fare = fare;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Ticket [id=");
		builder.append(id);
		builder.append(", travellers=");
		builder.append(travellers);
		builder.append(", fare=");
		builder.append(fare);
		builder.append(", flight=");
		builder.append(flight);
		builder.append(", email=");
		builder.append(email);
		builder.append(", contactNo=");
		builder.append(contactNo);
		builder.append(", userID=");
		builder.append(userID);
		builder.append(", name=");
		builder.append(name);
		builder.append("]");
		return builder.toString();
	}
	
}
