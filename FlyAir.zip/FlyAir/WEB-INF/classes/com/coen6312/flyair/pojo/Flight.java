package com.coen6312.flyair.pojo;

import java.math.BigDecimal;
import java.util.Date;

public class Flight {
	private String id;
	private String source;
	private String destination;
	private Date departDate;
	private String departTime;
	private String duration;
	private Date arrivalDate;
	private String arrivalTime;
	private String totalSeats;
	private BigDecimal fare;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getDepartDate() {
		return departDate;
	}
	public void setDepartDate(Date departDate) {
		this.departDate = departDate;
	}
	public String getDepartTime() {
		return departTime;
	}
	public void setDepartTime(String departTime) {
		this.departTime = departTime;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public Date getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(Date arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public String getTotalSeats() {
		return totalSeats;
	}
	public void setTotalSeats(String totalSeats) {
		this.totalSeats = totalSeats;
	}
	public BigDecimal getFare() {
		return fare;
	}
	public void setFare(BigDecimal fare) {
		this.fare = fare;
	}
	
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Flight [id=");
		builder.append(id);
		builder.append(", source=");
		builder.append(source);
		builder.append(", destination=");
		builder.append(destination);
		builder.append(", departDate=");
		builder.append(departDate);
		builder.append(", departTime=");
		builder.append(departTime);
		builder.append(", duration=");
		builder.append(duration);
		builder.append(", arrivalDate=");
		builder.append(arrivalDate);
		builder.append(", arrivalTime=");
		builder.append(arrivalTime);
		builder.append(", totalSeats=");
		builder.append(totalSeats);
		builder.append(", fare=");
		builder.append(fare);
		builder.append("]");
		return builder.toString();
	}
	
	
}
