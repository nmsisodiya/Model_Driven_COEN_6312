package com.coen6312.flyair.pojo;

public class Traveller extends Person{
	private String name;
	private String age;
	private String contactno;
	private String email;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getContactno() {
		return contactno;
	}
	public void setContactno(String contactno) {
		this.contactno = contactno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "Traveller [name=" + name + ", age=" + age + ", contactno="
				+ contactno + ", email=" + email + "]";
	}
	
}
