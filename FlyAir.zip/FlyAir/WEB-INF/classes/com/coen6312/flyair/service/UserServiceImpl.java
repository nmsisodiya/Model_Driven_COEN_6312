package com.coen6312.flyair.service;

import java.util.List;

import com.coen6312.flyair.dao.IUserDao;
import com.coen6312.flyair.dao.UserDaoImpl;
import com.coen6312.flyair.exception.UserException;
import com.coen6312.flyair.pojo.User;

public class UserServiceImpl implements IUserService {
	
	IUserDao userDao = new UserDaoImpl();

	public User validateUser(User user) throws UserException{
		
		try {
			List<User> userList = userDao.validateUser(user);
			if(userList != null && !userList.isEmpty()){
				return userList.get(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserException(e);
		}
		return null;
	}
	
	public int signup(User user) throws UserException{
		try {
			String username = userDao.getUsername(user);
			if(username !=null){
				throw new UserException("Username already available.");
			}
			return userDao.addUser(user);
		} catch (Exception e) {
			e.printStackTrace();
			throw new UserException(e);
		}
	}

}
