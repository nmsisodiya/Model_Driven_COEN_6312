package com.coen6312.flyair.service;

import java.util.List;

import com.coen6312.flyair.pojo.Flight;
import com.coen6312.flyair.pojo.Ticket;
import com.coen6312.flyair.pojo.User;

public interface IFlightService {
	public List<Flight> searchFlights(Flight flight) throws Exception;
	
	public List<Flight> searchFlightsById(Flight flight) throws Exception;
	
	public void addFlights(Flight flight) throws Exception;

	public void bookTicket(Ticket ticket) throws Exception;

	public List<Ticket> getHistory(User user)throws Exception;
}
