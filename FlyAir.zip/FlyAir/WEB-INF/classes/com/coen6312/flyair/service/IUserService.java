package com.coen6312.flyair.service;

import com.coen6312.flyair.exception.UserException;
import com.coen6312.flyair.pojo.User;

public interface IUserService {
	public User validateUser(User user) throws UserException;

	public int signup(User user) throws UserException;

}
