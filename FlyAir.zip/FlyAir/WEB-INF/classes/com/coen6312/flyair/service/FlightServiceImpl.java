package com.coen6312.flyair.service;

import java.util.List;

import com.coen6312.flyair.dao.FlightDaoImpl;
import com.coen6312.flyair.dao.IFlightDao;
import com.coen6312.flyair.pojo.Flight;
import com.coen6312.flyair.pojo.Ticket;
import com.coen6312.flyair.pojo.User;

public class FlightServiceImpl implements IFlightService {
	IFlightDao flightDao = new FlightDaoImpl();
	
	@Override
	public List<Flight> searchFlights(Flight flight) throws Exception {
		List<Flight> flights = flightDao.searchFlights(flight);
		return flights;
	}
	
	@Override
	public List<Flight> searchFlightsById(Flight flight) throws Exception {
		List<Flight> flights = flightDao.searchFlightsById(flight);
		return flights;
	}

	@Override
	public void addFlights(Flight flight) throws Exception {
		flightDao.addFlights(flight);
	}

	@Override
	public void bookTicket(Ticket ticket) throws Exception {
		flightDao.bookTicket(ticket);
	}

	@Override
	public List<Ticket> getHistory(User user) throws Exception {
		return flightDao.getHistory(user);
	}
	
}
