package com.coen6312.flyair.commons;

public class Queries {

	public static final String GET_USER = "select * from TBL_USER where username = ? and password = ?";
	public static final String GET_USERNAME = "select username from TBL_USER where username = ?";
	public static final String ADD_USER = "INSERT INTO TBL_USER (NAME, USERNAME, PASSWORD, EMAIL, PHONE_NUMBER,ROLE) values (?,?,?,?,?,?)";
	public static final String SEARCH_FLIGHT = "select Id,source, destination, date_Of_Journey ,total_Seats, departure ,arrival, duration , fare, depart_time from flight where source = ? and destination = ? AND date_of_journey BETWEEN ? AND ?";
	public static final String SEARCH_FLIGHT_BY_ID = "select Id,source, destination, date_Of_Journey ,total_Seats, departure ,arrival, duration , fare, depart_time from flight where id = ? ";
	public static final String BOOK_TICKET = "INSERT INTO TICKET ( SOURCE, DESTINATION, DATE_OF_JOURNEY, depart_time, DURATION, TOTAL_SEATS, FARE, FLIGHTID, EMAIL, CONTACTNO, USERID, TRAVELLER_NAME) values (?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String GET_HISTORY = "select SOURCE, DESTINATION, DATE_OF_JOURNEY,depart_time, DURATION, TOTAL_SEATS, FARE, FLIGHTID, EMAIL, CONTACTNO, USERID, TRAVELLER_NAME from ticket where upper(userid)=?";
	public static final String ADD_FLIGHT = "INSERT INTO FLIGHT (SOURCE,DESTINATION,DATE_OF_JOURNEY,DEPART_TIME,DURATION,FARE) VALUES (?,?,?,?,?,?)";
}
