package com.coen6312.flyair.commons;

public class Constants {

	public static final String LOGIN = "loginpage";
	public static final String USERNAME = "username";
	public static final String ROLE = "role";
	public static final String USER = "user";
	public static final String LOGOUT = "logout";
	public static final int TIME = 5;
	public static final String SIGNUP = "signup";
	public static final String ADD_FLIGHT = "add_flight";
	public static final String SEARCH_FLIGHT = "search_flight";
	public static final String BOOK_FLIGHT = "book_flight";
	public static final String BOOK_TICKET = "book_ticket";
	public static final String HISTORY = "history";
	
}
