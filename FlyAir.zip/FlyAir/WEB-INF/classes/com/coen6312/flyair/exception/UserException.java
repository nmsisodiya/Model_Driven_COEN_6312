package com.coen6312.flyair.exception;

public class UserException extends Exception {
	public UserException() {
		super();
	}
	
	public UserException(String message) {
		super(message);
	}
	
	public UserException(Throwable e){
		super(e);
	}
}
