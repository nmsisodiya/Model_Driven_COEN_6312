package com.coen6312.flyair.dbutils;

import java.sql.*;
import java.util.Properties;
import java.io.FileInputStream;

public class DBConnect{
    static String url;
    static String driver;
    static String uname;
    static String upass;        
    static Connection conn;
    static Properties prop;
    static {
        try{
            FileInputStream fis=new FileInputStream("./db.properties") ;
            prop=new Properties();
            prop.load(fis);
        }
        catch(Exception ex){
            ex.printStackTrace();   
        }
    }
    public static Connection connect() throws Exception{
        
            if(prop!=null){
              url=prop.getProperty("url");
              driver=prop.getProperty("driver");
              uname=prop.getProperty("uname");
              upass=prop.getProperty("upass");
            }
              Class.forName(driver).newInstance();
              conn = DriverManager.getConnection(url,uname,upass);
              //System.out.println("Connected to the database");
              return conn;
    }
    
    public static void disconnect(Connection conn) throws Exception{
              conn.close();
              //System.out.println("Disconnected from database");
    }
}


//export CLASSPATH=$CLASSPATH:/home/sachin/drivers/mysql-connector-java-5.1.13-bin.jar


