package com.coen6312.flyair.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.coen6312.flyair.commons.Queries;
import com.coen6312.flyair.dbutils.DBConnect;
import com.coen6312.flyair.pojo.Flight;
import com.coen6312.flyair.pojo.Ticket;
import com.coen6312.flyair.pojo.User;
import com.coen6312.flyair.service.FlightServiceImpl;

public class FlightDaoImpl implements IFlightDao {

	@Override
	public List<Flight> searchFlights(Flight flight) throws Exception {
		List<Flight> flights = new ArrayList<Flight>();
		 Connection connection = DBConnect.connect();
		 
		 PreparedStatement psmt = connection.prepareStatement(Queries.SEARCH_FLIGHT);
		 int parameterIndex = 1;
		 psmt.setString(parameterIndex++, flight.getSource());
		 psmt.setString(parameterIndex++, flight.getDestination());
		 psmt.setDate(parameterIndex++, new Date(flight.getDepartDate().getTime()));
		 psmt.setDate(parameterIndex++, new Date(flight.getDepartDate().getTime()));
		 ResultSet rs = psmt.executeQuery();
		 while(rs.next()){
			 Flight flightFromDb = new Flight();
			 flightFromDb.setId(rs.getString("ID"));
			 flightFromDb.setSource(flight.getSource());
			 flightFromDb.setDestination(flight.getDestination());
			 flightFromDb.setFare(new BigDecimal(rs.getString("fare")));
			 flightFromDb.setDuration(rs.getString("duration"));
			 flightFromDb.setDepartTime(rs.getString("depart_time"));
			 flightFromDb.setDepartDate(flight.getDepartDate());
			 flights.add(flightFromDb);
			 
		 }
		 DBConnect.disconnect(connection);
		return flights;
	}
	
	
	@Override
	public List<Flight> searchFlightsById(Flight flight) throws Exception {
		List<Flight> flights = new ArrayList<Flight>();
		Connection connection = DBConnect.connect();
		 
		 PreparedStatement psmt = connection.prepareStatement(Queries.SEARCH_FLIGHT_BY_ID);
		 int parameterIndex = 1;
		 psmt.setString(parameterIndex++, flight.getId());
		 ResultSet rs = psmt.executeQuery();
		 while(rs.next()){
			 Flight flightFromDb = new Flight();
			 flightFromDb.setId(rs.getString("ID"));
			 flightFromDb.setSource(rs.getString("SOURCE"));
			 flightFromDb.setDestination(rs.getString("DESTINATION"));
			 flightFromDb.setFare(new BigDecimal(rs.getString("FARE")));
			 flightFromDb.setDuration(rs.getString("DURATION"));
			 flightFromDb.setDepartDate(rs.getDate("DATE_OF_JOURNEY"));
			 flightFromDb.setDepartTime(rs.getString("depart_time"));
			 flights.add(flightFromDb);
		 }
		 DBConnect.disconnect(connection);
		return flights;
	}

	@Override
	public void addFlights(Flight flight) throws Exception {
		Connection connection = DBConnect.connect();
		PreparedStatement psmt = connection.prepareStatement(Queries.ADD_FLIGHT);
		 //(SOURCE, DESTINATION, DATE_OF_JOURNEY, DURATION, TOTAL_SEATS, FARE, FLIGHTID, EMAIL, CONTACTNO, USERID, TRAVELLER_NAME)
		 int parameterIndex = 1;
		 psmt.setString(parameterIndex++,flight.getSource());
		 psmt.setString(parameterIndex++,flight.getDestination());
		 psmt.setDate(parameterIndex++,new Date(flight.getDepartDate().getTime()));
		 psmt.setString(parameterIndex++,flight.getDepartTime());
		 psmt.setString(parameterIndex++,flight.getDuration());
		 psmt.setBigDecimal(parameterIndex++,flight.getFare());
		 psmt.executeUpdate();		 
		 DBConnect.disconnect(connection);
	}


	@Override
	public void bookTicket(Ticket ticket) throws Exception{
		Connection connection = DBConnect.connect();
		PreparedStatement psmt = connection.prepareStatement(Queries.BOOK_TICKET);
		 //(SOURCE, DESTINATION, DATE_OF_JOURNEY, DURATION, TOTAL_SEATS, FARE, FLIGHTID, EMAIL, CONTACTNO, USERID, TRAVELLER_NAME)
		 for (String name : ticket.getTravellers()) {
			 int parameterIndex = 1;
			 psmt.setString(parameterIndex++,ticket.getFlight().getSource());
			 psmt.setString(parameterIndex++,ticket.getFlight().getDestination());
			 psmt.setDate(parameterIndex++,new Date(ticket.getFlight().getDepartDate().getTime()));
			 psmt.setString(parameterIndex++,ticket.getFlight().getDepartTime());
			 psmt.setString(parameterIndex++,ticket.getFlight().getDuration());
			 psmt.setString(parameterIndex++,ticket.getFlight().getTotalSeats());
			 psmt.setBigDecimal(parameterIndex++,ticket.getFlight().getFare());
			 psmt.setString(parameterIndex++,ticket.getFlight().getId());
			 psmt.setString(parameterIndex++,ticket.getEmail());
			 psmt.setString(parameterIndex++,ticket.getContactNo());
			 psmt.setString(parameterIndex++,ticket.getUserID());
			 psmt.setString(parameterIndex++,name);
			 psmt.executeUpdate();
		 }
		 
		 DBConnect.disconnect(connection);
		
	}


	@Override
	public List<Ticket> getHistory(User user) throws Exception {
		List<Ticket> tickets = new ArrayList<Ticket>();
		Connection connection = DBConnect.connect();
		 
		 PreparedStatement psmt = connection.prepareStatement(Queries.GET_HISTORY);
		 int parameterIndex = 1;
		 psmt.setString(parameterIndex++, user.getUsername().toUpperCase());
		 ResultSet rs = psmt.executeQuery();
		 while(rs.next()){
			Ticket ticket = new Ticket();
			//(SOURCE, DESTINATION, DATE_OF_JOURNEY, DURATION, TOTAL_SEATS, FARE, FLIGHTID, EMAIL, CONTACTNO, USERID, TRAVELLER_NAME)
			ticket.setName(rs.getString("TRAVELLER_NAME"));
			ticket.setEmail(rs.getString("EMAIL"));
			ticket.setUserID(rs.getString("USERID"));
			ticket.setContactNo(rs.getString("CONTACTNO"));
			ticket.getFlight().setSource(rs.getString("SOURCE"));
			ticket.getFlight().setDepartDate(rs.getDate("DATE_OF_JOURNEY"));
			ticket.getFlight().setDepartTime(rs.getString("depart_time"));
			ticket.getFlight().setDestination(rs.getString("DESTINATION"));
			ticket.getFlight().setDuration(rs.getString("DURATION"));
			ticket.getFlight().setTotalSeats(rs.getString("TOTAL_SEATS"));
			ticket.getFlight().setFare(rs.getBigDecimal("FARE"));
			tickets.add(ticket);
		 }
		 DBConnect.disconnect(connection);
		return tickets;
	}

}
