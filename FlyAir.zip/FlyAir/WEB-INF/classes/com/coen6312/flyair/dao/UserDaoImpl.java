package com.coen6312.flyair.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.coen6312.flyair.commons.Queries;
import com.coen6312.flyair.dbutils.DBConnect;
import com.coen6312.flyair.pojo.User;

public class UserDaoImpl implements IUserDao {
	Connection connection = null;
	PreparedStatement statement = null;

	public List<User> validateUser(User user) throws Exception {

		List<User> userList = new ArrayList<User>();
		int index = 1;
		connection = DBConnect.connect();
		statement = connection.prepareStatement(Queries.GET_USER);
		statement.setString(index++, user.getUsername());
		statement.setString(index++, user.getPassword());
		ResultSet resultSet = statement.executeQuery();
		if (resultSet.next()) {
			User newUser = new User();
			newUser.setName(resultSet.getString("NAME"));
			newUser.setUsername(resultSet.getString("USERNAME"));
			newUser.setEmail(resultSet.getString("EMAIL"));
			newUser.setPhoneNumber(resultSet.getString("PHONE_NUMBER"));
			newUser.setRole(resultSet.getString("ROLE"));
			userList.add(newUser);
		}
		DBConnect.disconnect(connection);

		return userList;
	}

	public int addUser(User user) throws Exception{
		int count = 0; // NAME, USERNAME, PASSWORD, EMAIL, PHONE_NUMBER
		int index = 1;
		connection = DBConnect.connect();
		statement = connection.prepareStatement(Queries.ADD_USER);
		statement.setString(index++, user.getName());
		statement.setString(index++, user.getUsername());
		statement.setString(index++, user.getPassword());
		statement.setString(index++, user.getEmail());
		statement.setString(index++, user.getPhoneNumber());
		statement.setString(index++, "user");
		count = statement.executeUpdate();
		DBConnect.disconnect(connection);
		return count;
	}

	public String getUsername(User user) throws Exception {
		int index = 1;
		connection = DBConnect.connect();
		statement = connection.prepareStatement(Queries.GET_USERNAME);
		statement.setString(index++, user.getUsername());
		ResultSet resultSet = statement.executeQuery();
		if (resultSet.next()) {
			return resultSet.getString("USERNAME");
		}
		DBConnect.disconnect(connection);
		return null;
	}

}
