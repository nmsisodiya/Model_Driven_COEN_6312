package com.coen6312.flyair.dao;

import java.util.List;

import com.coen6312.flyair.pojo.Flight;
import com.coen6312.flyair.pojo.Ticket;
import com.coen6312.flyair.pojo.User;

public interface IFlightDao {
	List<Flight> searchFlights(Flight flight) throws Exception;

	void addFlights(Flight flight) throws Exception;
	
	public List<Flight> searchFlightsById(Flight flight) throws Exception ;

	public void bookTicket(Ticket ticket) throws Exception;

	List<Ticket> getHistory(User user) throws Exception;

}
