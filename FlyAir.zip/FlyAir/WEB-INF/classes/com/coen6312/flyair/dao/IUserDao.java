package com.coen6312.flyair.dao;

import java.util.List;

import com.coen6312.flyair.pojo.User;

public interface IUserDao {
	public List<User> validateUser(User user) throws Exception;

	public int addUser(User user) throws Exception;

	public String getUsername(User user) throws Exception;

}
