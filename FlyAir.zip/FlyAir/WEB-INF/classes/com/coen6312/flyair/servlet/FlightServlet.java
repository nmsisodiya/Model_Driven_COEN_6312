package com.coen6312.flyair.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.coen6312.flyair.commons.Constants;
import com.coen6312.flyair.exception.UserException;
import com.coen6312.flyair.pojo.Flight;
import com.coen6312.flyair.pojo.Ticket;
import com.coen6312.flyair.pojo.User;
import com.coen6312.flyair.service.FlightServiceImpl;
import com.coen6312.flyair.service.IFlightService;
import com.coen6312.flyair.service.IUserService;
import com.coen6312.flyair.service.UserServiceImpl;

/**
 * Servlet implementation class FlightServlet
 */

public class FlightServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FlightServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doTask(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doTask(request, response);
	}
	private void doTask(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IUserService userService = new UserServiceImpl();
		IFlightService flightService = new FlightServiceImpl();
		HttpSession session = request.getSession(false);
		
		String page = request.getParameter("pagename");
		if(page != null){
			if(page.equalsIgnoreCase(Constants.ADD_FLIGHT)){
				try {
					Flight flight = new Flight();
					flight.setSource(request.getParameter("source"));
					flight.setDestination(request.getParameter("destination"));
					flight.setDepartDate(new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("depart_date")));
					flight.setDepartTime(request.getParameter("depart_time"));
					flight.setDuration(request.getParameter("travel_duration"));
					flight.setFare(new BigDecimal(request.getParameter("fare")));
					flightService.addFlights(flight);
					request.setAttribute("message", "Flight added successfully");
					request.getRequestDispatcher("./add_flight.jsp").forward(request, response);
				} catch (Exception e) {
					e.printStackTrace();
					if(e.getCause()== null){
						request.setAttribute("message", "Exception in adding flight");
					}else{
						request.setAttribute("message", "Exception in adding flight : "+e.getCause().getMessage());
					}
					request.getRequestDispatcher("./add_flight.jsp").forward(request, response);
				}
			}
			
			if(page.equalsIgnoreCase(Constants.SEARCH_FLIGHT)){
				try {
					Flight flight = new Flight();
					flight.setSource(request.getParameter("source"));
					flight.setDestination(request.getParameter("destination"));
					flight.setDepartDate(new SimpleDateFormat("dd/MM/yyyy").parse(request.getParameter("depart_date")));
					String totaltraveller = request.getParameter("totaltraveller");
					List<Flight> flights = flightService.searchFlights(flight);
					if(session != null){
						session.setAttribute("flights", flights);
						request.setAttribute("totaltraveller", totaltraveller);
					}
					request.getRequestDispatcher("./flights.jsp").forward(request, response);
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("message", "Exception in adding flight : "+e.getCause().getMessage());
					request.getRequestDispatcher("./search_flight.jsp").forward(request, response);
				}
			}
			
			if(page.equalsIgnoreCase(Constants.BOOK_FLIGHT)){
				try {
					if(session != null && session.getAttribute(Constants.USER)!=null){	
						Flight flight = new Flight();
						flight.setId(request.getParameter("id"));
						List<Flight> flights = flightService.searchFlightsById(flight);
						
						Flight flightFromDb = flights.get(0);
						String totaltraveller = request.getParameter("totaltraveller");
						flightFromDb.setTotalSeats(totaltraveller); 
						flightFromDb.setFare(flightFromDb.getFare().multiply(new BigDecimal(totaltraveller)));
						
						if(flights!=null && !flights.isEmpty()){
							request.setAttribute("flight", flightFromDb);
						}
						request.getRequestDispatcher("./bookflight.jsp").forward(request, response);
					}else{
						String redirecturl=new StringBuilder("./flight?pagename=book_flight&id=").append(request.getParameter("id")).append("&totaltraveller=").append(request.getParameter("totaltraveller")).toString();
						request.setAttribute("redirecturl", redirecturl);
						request.getRequestDispatcher("./login.jsp").forward(request, response);
					}
				} catch (Exception e) {
					e.printStackTrace();
					if(e.getCause()!=null){
						request.setAttribute("message", "Exception in booking flight : "+e.getCause().getMessage());
					}
					request.setAttribute("message", "Exception in booking flight. ");
					request.getRequestDispatcher("./search_flight.jsp").forward(request, response);
				}
			}
			
			if(page.equalsIgnoreCase(Constants.BOOK_TICKET)){
				try {
					User user = null;
					if(session !=null ){
						user = (User) session.getAttribute(Constants.USER);
						Flight flight = new Flight();
						flight.setId(request.getParameter("id"));
						List<Flight> flights = flightService.searchFlightsById(flight);
						List<String> travellers = Arrays.asList(request.getParameterValues("traveller"));
						Ticket ticket = new Ticket();
						if(flights!=null && !flights.isEmpty()){
							Flight flightFromDb = flights.get(0);
							ticket.setFlight(flightFromDb);
							ticket.setTravellers(travellers);
							ticket.setFare(flightFromDb.getFare().multiply(new BigDecimal(travellers.size())));
							ticket.setEmail(request.getParameter("email"));
							ticket.setContactNo(request.getParameter("contactno"));
							ticket.setUserID(user == null ? "test": user.getUsername());
							flightService.bookTicket(ticket);
						}
						request.setAttribute("message", "Ticket booked successfully. ");
						request.setAttribute("ticket", ticket);
						request.getRequestDispatcher("./success.jsp").forward(request, response);
					}
				} catch (Exception e) {
					e.printStackTrace();
					if(e.getCause()!=null){
						request.setAttribute("message", "Exception in booking flight : "+e.getCause().getMessage());
					}
					request.setAttribute("message", "Exception in booking flight. ");
					request.getRequestDispatcher("./search_flight.jsp").forward(request, response);
				}
			}
			
			if(page.equalsIgnoreCase(Constants.HISTORY)){
				try {
					if(session == null ){
						request.setAttribute("message", "Exception in showing history. ");
						request.getRequestDispatcher("./search_flight.jsp").forward(request, response);
					}
					else{
						User user = (User) session.getAttribute(Constants.USER);
						List<Ticket> tickets = flightService.getHistory(user);
						session.setAttribute("ticket", tickets);
						request.getRequestDispatcher("./history.jsp").forward(request, response);

					}					
				} catch (Exception e) {
					e.printStackTrace();
					if(e.getCause()!=null){
						request.setAttribute("message", "Exception in booking flight : "+e.getCause().getMessage());
					}
					request.setAttribute("message", "Exception in booking flight. ");
					request.getRequestDispatcher("./search_flight.jsp").forward(request, response);
				}
			}
		}
	}
	


}
