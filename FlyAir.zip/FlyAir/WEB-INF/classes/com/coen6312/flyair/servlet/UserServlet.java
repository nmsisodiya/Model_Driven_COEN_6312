package com.coen6312.flyair.servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.coen6312.flyair.commons.Constants;
import com.coen6312.flyair.exception.UserException;
import com.coen6312.flyair.pojo.Flight;
import com.coen6312.flyair.pojo.User;
import com.coen6312.flyair.service.FlightServiceImpl;
import com.coen6312.flyair.service.IFlightService;
import com.coen6312.flyair.service.IUserService;
import com.coen6312.flyair.service.UserServiceImpl;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * Default constructor.
	 */
	public UserServlet() {

	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doTask(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doTask(request, response);
	}

	private void doTask(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		IUserService userService = new UserServiceImpl();
		IFlightService flightService = new FlightServiceImpl();
		String page = request.getParameter("pagename");
		if(page != null){
			if(page.equalsIgnoreCase(Constants.LOGIN)){
				try {
					User user = new User();
					user.setUsername(request.getParameter("uname"));
					user.setPassword(request.getParameter("upass"));
					
					user = userService.validateUser(user);
					if (user != null ){
						HttpSession session = request.getSession(true);
						session.setAttribute(Constants.USER, user);
						if("ADMIN".equalsIgnoreCase(user.getRole())){
							response.sendRedirect("./add_flight.jsp");
						}
						else{
							if(request.getParameter("redirecturl") !=null && !request.getParameter("redirecturl").equalsIgnoreCase("")){
								String redirecturl = request.getParameter("redirecturl");
								
								String id = redirecturl.substring(redirecturl.lastIndexOf("=")+1);
								Flight flight = new Flight();
								getFlight(flight, redirecturl);
								
								List<Flight> flightList = flightService.searchFlightsById(flight);
								
								if(flightList !=null && !flightList.isEmpty()){
									Flight flightFromDb = flightList.get(0);
									flightFromDb.setTotalSeats(flight.getTotalSeats()); 
									flightFromDb.setFare(flightFromDb.getFare().multiply(new BigDecimal(flight.getTotalSeats())));
									request.setAttribute("flight", flightFromDb);
								}
								request.getRequestDispatcher("./bookflight.jsp").forward(request, response);
							}
							request.getRequestDispatcher("./search_flight.jsp").forward(request, response);
						}
						
					}
					else{
						request.setAttribute("message", "Invalid credentials, Try again...");
						request.getRequestDispatcher("./login.jsp").forward(request, response);
					}
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("message", "Exception in signing in : "+e.getCause().getMessage());
					request.getRequestDispatcher("./login.jsp").forward(request, response);
				}
			}
			if(page.equalsIgnoreCase(Constants.SIGNUP)){
				try {
					User user = new User();
					user.setUsername(request.getParameter("username"));
					user.setPassword(request.getParameter("password"));
					user.setName(request.getParameter("name"));
					user.setEmail(request.getParameter("email"));
					user.setPhoneNumber(request.getParameter("contactno"));
					int count = userService.signup(user);
					if(request.getParameter("redirecturl") !=null){
						String redirecturl = request.getParameter("redirecturl");
						String id = redirecturl.substring(redirecturl.lastIndexOf("=")+1);
						Flight flight = new Flight();
						flight.setId(id);
						List<Flight> flightList = flightService.searchFlightsById(flight);
						request.setAttribute("flight", flightList.get(0));
						request.getRequestDispatcher("./bookflight.jsp").forward(request, response);
					}
					else{	
						request.setAttribute("message", "Successful sign up");
						request.getRequestDispatcher("./search_flight.jsp").forward(request, response);
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					request.setAttribute("message", "Error in signing up : "+e.getCause().getMessage());
					request.getRequestDispatcher("./add_user.jsp").forward(request, response);
				}
			}
			else if(page.equalsIgnoreCase(Constants.LOGOUT)){
				HttpSession session = request.getSession();
				session.invalidate();
				request.setAttribute("message", "Logged out...");
				request.getRequestDispatcher("./login.jsp").forward(request, response);
			}		
		}
	}

	private void getFlight(Flight flight, String redirecturl) {
		String[] abc = redirecturl.split("&");
		
		for (String string : abc) {
			if(string.contains("id=")){
				flight.setId(string.substring(string.indexOf("=")+1));
			}
			if(string.contains("totaltraveller=")){
				flight.setTotalSeats(string.substring(string.indexOf("=")+1));
			}
		}
	}
	
	
}
